package com.example.dictionary.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionary.Models.Definition;
import com.example.dictionary.R;
import com.example.dictionary.ViewHolders.DefinictionViewHolder;

import java.util.List;

public class DefinictionAdapter extends RecyclerView.Adapter<DefinictionViewHolder> {
    private Context context;
    private List<Definition> definitionList;

    public DefinictionAdapter(Context context, List<Definition> definitionList) {
        this.context = context;
        this.definitionList = definitionList;
    }



    @NonNull
    @Override
    public DefinictionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new DefinictionViewHolder(LayoutInflater.from(context).inflate(R.layout.definition_list_items, parent,false));

    }

    @Override
    public void onBindViewHolder(@NonNull DefinictionViewHolder holder, int position) {
        holder.textView_definiction.setText("Definicja: " + definitionList.get(position).getDefinition());
        holder.textView_example.setText("Przykład: "+definitionList.get(position).getExample());
        StringBuilder synonyms =new StringBuilder();
        StringBuilder antonyms =new StringBuilder();

        synonyms.append(definitionList.get(position).getSynonyms());
        synonyms.append(definitionList.get(position).getAntonyms());

        holder.synonyms.setText(synonyms);
        holder.antonyms.setText(antonyms);

        holder.synonyms.setSelected(true);
        holder.antonyms.setSelected(true);

    }

    @Override
    public int getItemCount() {
        return definitionList.size();
    }
}
