package com.example.dictionary.ViewHolders;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dictionary.R;

public class MeaningsViewHolder extends RecyclerView.ViewHolder {
    public TextView partsOfSpeech;
    public RecyclerView recycler_definiction;
    public MeaningsViewHolder(@NonNull View itemView) {
        super(itemView);
        partsOfSpeech = itemView.findViewById(R.id.partsOfSpeech);
        recycler_definiction = itemView.findViewById(R.id.recycler_definiction);


    }
}
